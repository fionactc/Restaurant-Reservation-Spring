package com.fiona.restaurant_reservation.repository;

import com.fiona.restaurant_reservation.entity.Role;
import org.springframework.data.repository.CrudRepository;

public interface RoleRepository extends CrudRepository<Role, Long>{
}
